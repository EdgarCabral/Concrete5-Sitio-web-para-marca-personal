<?php defined('C5_EXECUTE') or die("Access Denied.")?>
<?php if ($options->textFiltering) : ?>
		<input type="text" id="quicksearch" placeholder="<?php echo t('Search on Title') ?>" />
<?php endif ?>