<?php
namespace Concrete\Package\EasyImageGallery\Src\Helper;

use Concrete\Core\Backup\ContentImporter;

defined('C5_EXECUTE') or die(_("Access Denied."));

class MclInstaller extends ContentImporter
{

}
