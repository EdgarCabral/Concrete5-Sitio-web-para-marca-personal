# Font Awesome Font Icons for CKEditor
Add Font Awesome 4.7 font icons into your text using the CKEditor rich text editor.

**Features:**
- Add any of the 675 icons in Font Awesome 4.7 into your text

This addon uses a modified version of the CKAwesome CKEditor plugin.
http://blackdevelop.com/io/ckawesome
