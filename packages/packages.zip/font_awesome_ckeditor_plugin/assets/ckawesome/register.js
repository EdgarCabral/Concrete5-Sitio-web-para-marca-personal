if (typeof CKEDITOR !== 'undefined') {
    CKEDITOR.plugins.addExternal(
        'ckawesome',
        CCM_REL + '/packages/font_awesome_ckeditor_plugin/assets/ckawesome/'
    );
}
