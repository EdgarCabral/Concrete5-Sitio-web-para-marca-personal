<?php defined('C5_EXECUTE') or die('Access Denied.'); ?>
<div class="sg-scrapbook">
    <?php $view->inc('view.php', ['view' => $view]); ?>
</div>
