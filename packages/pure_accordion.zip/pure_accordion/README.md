# Pure-Accordion

A simple accordion for CMS Concrete5

[Package in marketplace](http://www.concrete5.org/marketplace/addons/simple-accrodion/)

[Live demo](https://www.pure-dev.ru/our-packages/accordion?login_as_demo=1&utm_source=concrete5&utm_medium=live_demo&utm_campaign=pure_accordion)

