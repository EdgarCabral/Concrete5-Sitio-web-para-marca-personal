<?php
/**
 * Created by Pure/Web
 * www.pure-web.ru
 * © 2017
 */

defined('C5_EXECUTE') or die("Access Denied.");
$view->inc('form.php');

?>