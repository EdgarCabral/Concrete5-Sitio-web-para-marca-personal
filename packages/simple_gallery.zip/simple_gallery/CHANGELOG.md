##### 1.0.7
- Fixed some typos/added additional formatting in README.md/CHANGELOG.MD
- Added proper version to $pkgVersion in controller

##### 1.0.6
- Added README.md for github

##### 1.0.5
- Changes to how localization is handled

##### 1.0.4
- Inline css is targeted by bID instead uniqueID
- Moved css/js to registerViewAssets()

##### 1.0.3
- Replaced 'javascript-localized' with 'addFooterItem'

##### 1.0.2
- Another localization fixes

##### 1.0.1
- Fixed bug with number of columns on tablet
- Some localization fixes

##### 1.0.0
- PRB approved

##### 0.9.1
- Removal of unnecessary files

##### 0.9.0
- Submission to marketplace